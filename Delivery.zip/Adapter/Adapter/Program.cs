﻿using static System.Console;

class MainApp
  {
    /// <summary>
    /// Entry point into console application.
    /// </summary>
    public static void Main()
    {
      Facade facade = new Facade();
 
      facade.MethodA();
      facade.MethodB();
 
      // Wait for user
      Console.ReadKey();
    }
  }
 
  /// <summary>
  /// The 'Subsystem ClassA' class
  /// </summary>
  class Road
{
    public void MethodOne()
    {
      Console.WriteLine(" On the road");
    }
  }
 
  /// <summary>
  /// The 'Subsystem ClassB' class
  /// </summary>
  class Expectation
{
    public void MethodTwo()
    {
      Console.WriteLine(" The package is waiting");
    }
  }
 
  /// <summary>
  /// The 'Subsystem ClassC' class
  /// </summary>
  class Theend
  {
    public void MethodThree()
    {
      Console.WriteLine(" The package has been taken away");
    }
  }
 
  /// <summary>
  /// The 'Subsystem ClassD' class
  /// </summary>
  class refund
{
    public void MethodFour()
    {
      Console.WriteLine(" Refund");
    }
  }
 

  class Facade
  {
    private Road _one;
    private Expectation _two;
    private Theend _three;
    private refund _four;
 
    public Facade()
    {
      _one = new Road();
      _two = new Expectation();
      _three = new Theend();
      _four = new refund();
    }
 
    public void MethodA()
    {
      Console.WriteLine("\ndelivery ");
      _one.MethodOne();
      _two.MethodTwo();
      _three.MethodThree();
        
    }
 
    public void MethodB()
    {
      Console.WriteLine("\nIn case of an error or other problems ");
        _four.MethodFour();
    }
  }