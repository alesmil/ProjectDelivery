﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;

namespace Template_method
{
    class Program
    {
        static void Main(string[] args)
        {
            School school = new School();
            University university = new University();

            school.Learn();
            university.Learn();

            Console.Read();
        }
    }
    abstract class Education
    {
        public void Learn()
        {
            Enter();
            Study();
            PassExams();
            GetDocument();
        }
        public abstract void Enter();
        public abstract void Study();
        public virtual void PassExams()

        {
            Console.WriteLine("Введите вес пачки");
            string number = Console.ReadLine();
            if (Convert.ToInt32(number) < 5)
            {
                Console.WriteLine("Вам предоставленны такие виды доставки. Выберете 1 из них");
                Console.WriteLine("Чтобы выбрать доставку укажите цифру которая стоит рядом: " );
                Console.WriteLine(" ");
                Console.WriteLine("Выбор Доставки: ");
                Console.WriteLine("Доставка на дом 1 ");
                Console.WriteLine("Доставка в магазин 2");
                Console.WriteLine("Доставка в пачкомат 3");
                string age = Console.ReadLine();
                if (Convert.ToInt32(age) == 1)
                {
                    Console.WriteLine("Вы выбрали доставку номер 1");
                    Console.WriteLine("Доставка на дом ", "\n");

                }
                else if(Convert.ToInt32(age) == 2)
                {
                    Console.WriteLine("Вы выбрали доставку номер 2");
                    Console.WriteLine("Доставка в магазин ", "\n");
                }
                else if (Convert.ToInt32(age) == 3)
                {
                    Console.WriteLine("Вы выбрали доставку номер 3");
                    Console.WriteLine("Доставка в пачкомат  ", "$0\n");
                }
            }
            else if (Convert.ToInt32(number) < 10)
            {
                Console.WriteLine("Вам предоставленны такие виды доставки. Выберете 1 из них");
                Console.WriteLine("Чтобы выбрать доставку укажите цифру которая стоит рядом: ");
                Console.WriteLine(" ");
                Console.WriteLine("Выбор Доставки: ");
                Console.WriteLine("Доставка на дом 1 ");
                Console.WriteLine("Доставка в пачкомат 2");
                string age = Console.ReadLine();
                if (Convert.ToInt32(age) == 1)
                {
                    Console.WriteLine("Вы выбрали доставку номер 1");
                    Console.WriteLine("Доставка на дом ", "\n");

                }
                
                else if (Convert.ToInt32(age) == 2)
                {
                    Console.WriteLine("Вы выбрали доставку номер 2");
                    Console.WriteLine("Доставка в пачкомат  ", "$0\n");
                }
            }
            else if (Convert.ToInt32(number) > 10)
            {
                Console.WriteLine("Вам предоставленны такие виды доставки. Выберете 1 из них");
                Console.WriteLine("Чтобы выбрать доставку укажите цифру которая стоит рядом: ");
                Console.WriteLine(" ");
                Console.WriteLine("Выбор Доставки: ");
                Console.WriteLine("Доставка на дом 1 ");
                string age = Console.ReadLine();
                if (Convert.ToInt32(age) == 1)
                {
                    Console.WriteLine("Вы выбрали доставку номер 1");
                    Console.WriteLine("Доставка на дом ", "\n");

                }
            }
        }
        public abstract void GetDocument();
    }

    class School : Education
    {
        public override void Enter()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Получаем заказ");
        }

        public override void Study()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Проверяем заказ на целостность");
        }

        public override void GetDocument()
        {
            Console.WriteLine(" ");
            Console.WriteLine("день доставки");
            Console.WriteLine(DateTime.Now + "  В этот день вы сделали заказ");
            Console.WriteLine( DateTime.Now.AddDays(2) +   "  В это день заказ будет у вас");

        }
    }

    class University : Education
    {
        public override void Enter()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Создаем код для клиента");
        }

        public override void Study()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Проверяем код");
       
            Random rnd = new Random();
            int value = rnd.Next();
            Console.WriteLine(value);

            Console.WriteLine("Высылаем код");
        }
        class mail
        {
            private void man(string[] args)
            {

                SendEmailAsync().GetAwaiter();
                Console.Read();
            }

            private static async Task SendEmailAsync()
            {

                // отправитель - устанавливаем адрес и отображаемое в письме имя
                MailAddress from = new MailAddress("s3766588@gmail.com", "Nomer 1");
                // кому отправляем
                MailAddress to = new MailAddress("alesmil1000@gmail.com");
                // создаем объект сообщения
                MailMessage m = new MailMessage(from, to);
                // тема письма
                m.Subject = "Тест";
                // текст письма
                m.Body = "<h2>Письмо-тест работы smtp-клиента</h2>";
                // письмо представляет код html
                m.IsBodyHtml = true;
                // адрес smtp-сервера и порт, с которого будем отправлять письмо
                SmtpClient smtp = new SmtpClient("s3766588@gmail.com", 587);
                // логин и пароль
                smtp.Credentials = new NetworkCredential("s3766588@gmail.com", "A12345678!");
                smtp.EnableSsl = true;
                smtp.Send(m);
                Console.Read();
            }
        }

        public override void PassExams()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Доставка");
        }

        public override void GetDocument()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Клиент получает поссылку");
        }
    }
}