﻿using static System.Console;

class MainApp
{

    public static void Main()
    {
        Facade facade = new Facade();

        facade.MethodA();
        facade.MethodB();

        Console.ReadKey();
    }
}

class Road
{
    public void MethodOne()
    {
        Console.WriteLine(" W drodze");
    }
}


class Expectation
{
    public void MethodTwo()
    {
        Console.WriteLine(" Paczka czeka");
    }
}


class Theend
{
    public void MethodThree()
    {
        Console.WriteLine(" Paczka została zabrana");
    }
}


class refund
{
    public void MethodFour()
    {
        Console.WriteLine(" Aby dokonać zwrotu trzeba:");
    }
}

class bled
{
    public void MethodFive()
    {
        Console.Write(" Napisz o przyczynie zwrotu: ");
        string? bled = Console.ReadLine();
        Console.WriteLine($" Powód zwrotu: {bled}");
        Console.Write(" Sprzedawca skontaktuje się z Tobą w ciągu 3 godzin. ");
    }
}

class Facade
{
    private Road _one;
    private Expectation _two;
    private Theend _three;
    private refund _four;
    private bled _five;

    public Facade()
    {
        _one = new Road();
        _two = new Expectation();
        _three = new Theend();
        _four = new refund();
        _five = new bled(); 
    }

    public void MethodA()
    {
        Console.WriteLine("\n delivery ");
        _one.MethodOne();
        _two.MethodTwo();
        _three.MethodThree();

    }

    public void MethodB()
    {
        Console.WriteLine("\n W przypadku błędu lub innych problemów ");
        _four.MethodFour();
        _five.MethodFive();
    }
}