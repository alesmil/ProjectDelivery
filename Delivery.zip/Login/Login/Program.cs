﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Login
{
    class Program
    {
        static void Main(string[] args)
        {
            string username, password, username1, password1 = string.Empty;

            Console.Write("Enter a username: ");
            username = Console.ReadLine();
            Console.Write("Enter a password: ");
            password = Console.ReadLine();

            using (StreamReader sr = new StreamReader(File.Open("C:\\1.txt", FileMode.Open)))
            {
                username1 = sr.ReadLine();
                password1 = sr.ReadLine();
                sr.Close();
            }

            if (username == username1 && password == password1)
            {
                Console.WriteLine("Logni succefu ");
            }
            else
            { 
                Console.WriteLine("Login Failing ");
            }

            Console.Read();

        }
    }
}