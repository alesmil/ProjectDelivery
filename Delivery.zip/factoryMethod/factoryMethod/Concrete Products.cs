﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Создали 3 типа класса для каждего метода
//это интрефейс, котороый мы создали 
namespace FactoryMethodDesignPattern
{
    public class Platinum : Bag
    {
        public string GetBagType()
        {
            return "Standart Bag";
        }
        public int GetBagLimit()
        {
            return 10;
        }
        public int GetBagCharge()
        {
            return 500;
        }
    }
    public class Titanium : Bag
    {
        public string GetBagType()
        {
            return "Titanium Bag";
        }
        public int GetBagLimit()
        {
            return 50;
        }
        public int GetBagCharge()
        {
            return 1500;
        }
    }
    public class MoneyBack : Bag
    {
        public string GetBagType()
        {
            return "Titanium Bag Plus";
        }
        public int GetBagLimit()
        {
            return 150;
        }
        public int GetBagCharge()
        {
            return 2000;
        }
    }
}