﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDesignPattern
{
    class Program
    {
        static void Main(string[] args)
        {

            Bag creditCard = new PlatinumFactory().CreateProduct();
            if (creditCard != null)
            {
                Console.WriteLine("Bag Type : " + creditCard.GetBagType());
                Console.WriteLine("Maksymalna waga paczki : " + creditCard.GetBagLimit());
                Console.WriteLine("Koszt :" + creditCard.GetBagCharge());
            }
            else
            {
                Console.Write("Invalid Bag Type");
            }
            Console.WriteLine("--------------");
            creditCard = new MoneyBackFactory().CreateProduct();
            if (creditCard != null)
            {
                Console.WriteLine("Bag Type : " + creditCard.GetBagType());
                Console.WriteLine("Maksymalna waga paczki : " + creditCard.GetBagLimit());
                Console.WriteLine("Koszt :" + creditCard.GetBagCharge());
            }
            else
            {
                Console.Write("Invalid Bag Type");
            }
            Console.ReadLine();
        }
    }
}