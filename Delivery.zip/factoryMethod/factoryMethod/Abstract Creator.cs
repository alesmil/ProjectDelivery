﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//фабричный метод, который возвращает(zwraca) объект типа Product
namespace FactoryMethodDesignPattern
{
    public abstract class CreditBagFactory
    {
        protected abstract Bag MakeProduct();
        public Bag CreateProduct()
        {
            return this.MakeProduct();
        }
    }
}