﻿namespace FactoryMethodDesignPattern
{
    public interface Bag
    {
        string GetBagType();
        int GetBagLimit();
        int GetBagCharge();
    }
}