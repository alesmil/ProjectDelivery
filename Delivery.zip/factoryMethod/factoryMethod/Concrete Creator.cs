﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//три типа кредитных карт, мы собираемся создать три класса
namespace FactoryMethodDesignPattern
    {
        public class MoneyBackFactory : CreditBagFactory
        {
            protected override Bag MakeProduct()
            {
                Bag product = new MoneyBack();
                return product;
            }
        }
        public class PlatinumFactory : CreditBagFactory
        {
            protected override Bag MakeProduct()
            {
                Bag product = new Platinum();
                return product;
            }
        }
        public class TitaniumFactory : CreditBagFactory
        {
            protected override Bag MakeProduct()
            {
                Bag product = new Titanium();
                return product;
            }
        }
    }

